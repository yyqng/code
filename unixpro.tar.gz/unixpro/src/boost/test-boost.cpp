#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <signal.h>
#include <unistd.h>
#include "smartpointers.h"
#include "time.h"
#include "log.h"

int
main(int argc, char *argv[])
{
    //smartpTest();
    //timerTest();
    logTest();
}

