#include "fileio.h"

int
main(int argc, char *argv[])
{
    //ls(argc ,argv);
    //copy_stdin_to_stdout( argc , argv);
    //copy_char_stdin_to_stdout( argc , argv);
    //lseek_test( argc , argv);
    //creat_holefile( argc , argv);
    lstat_test( argc , argv);
}
