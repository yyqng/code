#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <signal.h>
#include <unistd.h>
#include "malloc.h"
#include "sys/wait.h"
#include "ftoktest.h"
extern int errno;


void singnaltest(int argc , char *argv[] );
void killtest(int argc , char *argv[] );
void killchildtest(int argc , char *argv[] );
