#include <stdio.h>  
#include <sys/sem.h>  
#include <stdlib.h>  

int ftoktest(int argc, char *argv[]);
