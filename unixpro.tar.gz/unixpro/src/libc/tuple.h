#pragma once
#ifndef MY_TUPLE_H
#define MY_TUPLE_H
#include <tuple>
#include <iostream>
#include <string>
#include <stdexcept>


int tupleTest();
#endif
