#include "libc.h"
#include "libcpp.h"
#include "tuple.h"
#include "circular_buffer.h"

int
main(int argc, char *argv[])
{
    //assertTest();
    //ctypeTest();
    //errnoTest();
    //floatTest();
    //limitsTest();
    //localeTest();
    //mathTest();
    //setjmpTest();
    //signalTest();
    //stdargsTest(argc, argv);
    //stddefTest();
    //stdioTest();
    //libcpptest();
    tupleTest();
}
