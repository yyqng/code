#include <stdio.h>
#include <curl/curl.h>
#include <stdlib.h>
#include <iostream>
using namespace std;

int curlhttp(int argc, char *argv[]);
int curltcp(int argc, char *argv[]);
int curlwxy(int argc, char *argv[]);
