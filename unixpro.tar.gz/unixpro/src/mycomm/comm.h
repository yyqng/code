#pragma once

#if __cplusplus < 201103L

#include <cstddef>

# define nullptr NULL
# define final
# define override
# define constexpr
# define noexcept

#endif


#define MAX_SPIDER_TASK_LENGTH  (64 << 10)


