//#include "apue.h"
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <stdio.h>
#include <stdint.h>
#include <sstream>
void ls(int argc , char *argv[] );
void copy_stdin_to_stdout(int argc , char * argv[]);
void copy_char_stdin_to_stdout(int argc , char * argv[]);
void lseek_test(int argc , char * argv[]);
void creat_holefile(int argc , char * argv[]);
void lstat_test(int argc , char * argv[]);
//void err_sys(int argc , char * argv[])
//{
//}

