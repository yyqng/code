#pragma once

#define UNIX_DOMAIN_PATH	"SpiderTaskSocket"
#define SHM_PARSER_NAME 	"spider_result_01"
#define SHM_PARSER_SIZE 	(16 * 1024 * 1024)
