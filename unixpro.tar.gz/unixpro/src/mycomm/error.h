#include <stdio.h>
#include <errno.h>
void err_sys(const char *s);
