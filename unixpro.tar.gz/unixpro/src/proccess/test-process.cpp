#include "process.h"

int
main(int argc, char *argv[])
{
    //printXXID();
    //fork_execlp();
    forktest();
    //vforktest();
    //exittest();
    //competetest();
    //nocompetetest();
    
    return 0;
}
