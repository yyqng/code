#include "signal.h"

int
main(int argc, char *argv[])
{
   //singnaltest( argc , argv);
   sem_timedwaittest( argc , argv);

}
