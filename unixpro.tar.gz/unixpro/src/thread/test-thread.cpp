#include "thread.h"

int
main(int argc, char *argv[])
{
   threadtest( argc , argv);

}
