#include "single.h"
SINGLETON_CLASS_INIT(Single)

/*
void Single::Start()
{
}
void Single::Stop()
{
}
*/
