#include "hashtable.h"
#include "iaabc.h"
int main(void)
{
    //hashtableTest();
    Solution s;
    //s.maxSubArrayTest();
    //s.searchMatrixTest();
    //s.minCostClimbingStairsTest();
    //s.lengthOfLISTest();
    s.findOrderTest();
    return 0;
}

